Rushi Barevadiya Portfolio
===========================

Files:
- index.html — complete responsive portfolio website.

How to use:
1. Open index.html in Chrome/Edge.
2. To publish online, upload the file to GitHub Pages, Netlify, Vercel, or another static hosting service.
3. Replace the project placeholder cards with your actual images/videos when available.

Contact:
9429563541
barevadiyarushi@gmail.com
Parshottam Nagar, Althan Bhatar, Surat
